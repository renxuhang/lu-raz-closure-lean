"""Exact integer derivation/finite independent checks for the six-row spectrum.

No theorem-prover claims: all assertions in this script are reproducible finite
computations.  The pointwise group formulas use integer interval counts rather
than fitted data; their algebraic polynomial simplification is reported too.
"""
from pathlib import Path
from fractions import Fraction
import argparse
import hashlib
import json
import random
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
SEARCH = HERE
sys.path.insert(0, str(SEARCH))
from candidate_B_difference_forms import forms
from check_candidate_B import explicit_B
import search_from_variant as search


def v_frequency2(q, e):
    if e == 1: return 19*q*q+17*q-26
    if e == 2: return 17*q*q+21*q-30
    if e == 3: return 17*q*q+23*q-36
    if e == 4: return 16*q*q+34*q-46
    if e <= q+2: return 18*q*q+2*q*e+16*q-e*e-e-10
    if e == q+3: return 18*q*q+8*q-16
    if e <= 2*q: return 16*q*q+4*q*e-14*q-2*e*e+20*e-62
    if e == 2*q+1: return 16*q*q+34*q-64
    if e == 2*q+2: return 16*q*q+34*q-58
    if e <= 3*q: return 12*q*q+4*q*e+30*q-e*e-e-40
    if e == 3*q+1: return 17*q*q+33*q-54
    if e <= 4*q-2: return -14*q*q+16*q*e+40*q-2*e*e-4*e-26
    if e == 4*q-1: return 18*q*q+24*q-32
    return 18*q*q+24*q-40


def frequencies_of(members, n):
    values = [0]*n
    for mask in members:
        while mask:
            low = mask & -mask
            values[low.bit_length()-1] += 1
            mask -= low
    return values


def delta_by_enumeration(q):
    rem, add, _ = forms(q)
    removed, added = set().union(*rem.values()), set().union(*add.values())
    fr, fa = frequencies_of(removed, 4*q), frequencies_of(added, 4*q)
    return [a-r for r,a in zip(fr,fa)]


def le_count(a, b, x):
    """Number of integers t in [a,b] with t <= x."""
    return max(0, min(b,x)-a+1)


def ge_count(a, b, x):
    """Number of integers t in [a,b] with x <= t."""
    return max(0, b-max(a,x)+1)


def group_formula_counts(q, e):
    """43 exact pointwise counts from interval membership, not interpolation.

    At core coordinates 1..4, membership is constant over a group.  At all
    tail coordinates each one-parameter family is counted by a truncated
    integer interval.  Finite point families are direct indicator sums.
    """
    assert 4 <= q and 1 <= e <= 4*q
    h,n,r = 2*q,4*q,3*q+1
    core_totals_R = {
        'R2':(2,1),'R3':(3,1),'R4':(4,2),'R5':(5,1),
        'R6C_regular':(6,2*q-5),'R6C_exception':(6,1),'R6D':(6,2*q-4),
        'R7fresh':(7,3),'R7E':(7,q-2),'R7D':(7,2*q-4),
        'R10':(10,2),'R11J':(11,2*q-3),'R11AJ':(11,q-2),'R11AK':(11,2),
        'R12':(12,4),'R13CJ':(13,q-2),'R13ZJ':(13,2*q-4),
        'R13CZJ':(13,q-2),'R13points':(13,3),'R14points':(14,3),
        'R14line':(14,2*q-4),'R14C':(14,2*q-5),'R15points':(15,2),
        'R15right':(15,2*q-3),'R15gap':(15,q-1),'R15line':(15,2*q-4),
        'R15short':(15,2*q-4)}
    core_totals_N = {
        'N4':(4,2),'N5':(5,7),'N6C_regular':(6,2*q-5),
        'N6C_exception':(6,1),'N6E':(6,2*q-3),'N7C_regular':(7,2*q-5),
        'N7C_exception':(7,1),'N7right':(7,q-1),'N7point':(7,1),
        'N10':(10,3),'N11J':(11,2*q-3),'N11AJ':(11,q-2),'N11AK':(11,2),
        'N13plain':(13,q-1),'N13isolated':(13,q-2),'N13right':(13,q-3)}
    if e <= 4:
        return ({tag:count if core>>(e-1)&1 else 0 for tag,(core,count) in core_totals_R.items()},
                {tag:count if core>>(e-1)&1 else 0 for tag,(core,count) in core_totals_N.items()})
    i = lambda a,b: int(a <= e <= b)
    A,B,C = bool(i(5,q+2)), bool(i(r+1,n)), bool(i(5,h+2) or e==r)
    Ct,Cp = bool(i(5,h+1) or e==r), bool(i(5,h+1) or e==r or e==n-1)
    Lp,Zp,Ep = bool(i(5,h+1) or e==n),bool(i(5,h) or e in (n-1,n)),bool(i(h+3,n-2) or e==n)
    Lnew = bool(i(5,h+2))
    # beta(t)=h+t or h+t-1 on the two permitted parameter intervals.
    beta_count = le_count(4,q+1,e-h)+le_count(q+4,h,e-h+1)
    R = {
        'R2':i(h+1,n), 'R3':int(A or i(h+1,n)),
        'R4':2*int(C)+int(B and not C), 'R5':int(C),
        'R6C_regular':2*q-5 if C else beta_count,
        'R6C_exception':int(i(5,h+2) or i(r,n-1)),
        'R6D':2*q-4 if i(h+1,n) else ge_count(4,q+1,e)+ge_count(q+3,h-1,e)+1,
        'R7fresh':2*int(Ep)+int(A)+int(i(5,n-2) or e==n),
        'R7E':q-2 if i(h+3,n) else ge_count(4,q+1,e),
        'R7D':2*q-4 if i(h+1,n) else ge_count(4,h-1,e),
        'R10':le_count(h+2,h+3,e)*i(5,n-1),
        'R11J':le_count(5,h+1,e)*i(5,n-1),
        'R11AJ':q-2 if A else le_count(q+4,h+1,e)*i(5,n-1),
        'R11AK':2 if A else le_count(h+2,h+3,e)*i(5,n-1),
        'R12':4 if Lp else 2*int(C)+2*int(B),
        'R13CJ':q-2 if e==r else ge_count(h+2,r-2,e),
        'R13ZJ':2*q-4 if e==n else ge_count(h+2,n-3,e),
        'R13CZJ':q-2 if e in (r,n) else ge_count(h+2,r-2,e),
        'R13points':3 if Lp else int(B)+int(e==n-1),
        'R14points':2*i(5,n-2)+int(i(5,q+3) or i(h+3,n-1))+int(e==n),
        'R14line':2*q-4 if i(5,h+1) else le_count(h+4,n-1,e),
        'R14C':2*q-5 if C else le_count(h+4,n-1,e)-int(r+1<=e),
        'R15points':int(i(5,q+3) or i(h+3,n-1))+int(i(5,h+1) or i(h+3,n-2) or e==n),
        'R15right':2*q-3 if e==n else le_count(6,h+2,e)*i(5,n-2),
        'R15gap':q-1 if A or e==n else le_count(q+4,h+2,e)*i(5,n-2),
        'R15line':2*q-4 if i(5,h+1) else le_count(h+4,n-1,e),
        'R15short':2*ge_count(4,q+1,e)+le_count(h+2,h+3,e)*(q-2),
    }
    cp_reg = 2*q-5 if Ct else beta_count
    cp_exception = int(i(5,h+1) or i(r,n-1))
    N = {
        'N4':2*int(Cp)+int(B and not Cp),
        'N5':sum(map(int,[Lnew,Cp,Lnew or Cp,Lnew or Zp,Cp or Zp,Lnew or B,Cp or B])),
        'N6C_regular':cp_reg,'N6C_exception':cp_exception,
        'N6E':2*q-3 if i(h+3,n) else ge_count(4,q+1,e)+ge_count(q+3,h+1,e),
        'N7C_regular':cp_reg,'N7C_exception':cp_exception,
        'N7right':q-1 if Lnew else le_count(r+1,n-1,e)+int(i(r+1,n-1)),
        'N7point':int(i(5,h+1) or i(h+3,n)),
        'N10':3 if e==n else le_count(h+1,h+3,e)*i(5,n-2),
        'N11J':2*q-3 if e==n else le_count(5,h+1,e)*i(5,n-2),
        'N11AJ':q-2 if A or e==n else le_count(q+4,h+1,e)*i(5,n-2),
        'N11AK':2 if A or e==n else le_count(h+2,h+3,e)*i(5,n-2),
        'N13plain':ge_count(h+2,r-1,e),
        'N13isolated':q-2 if e in (r,n-1) else ge_count(h+2,r-2,e),
        'N13right':q-3 if e==n-1 else ge_count(r,n-3,e),
    }
    assert R.keys()==core_totals_R.keys() and N.keys()==core_totals_N.keys()
    return R,N


def delta_formula(q,e):
    if e==1: return 13-8*q
    if e==2: return 15-11*q
    if e==3: return 17-12*q
    if e==4: return 12-12*q
    if e<=q+2: return 3*e-10*q+3
    if e==q+3: return 10-6*q
    if e<=2*q: return 15-5*q-e
    if e==2*q+1: return 20-11*q
    if e==2*q+2: return 19-12*q
    if e==3*q+1: return 15-11*q
    if e<=4*q-2: return 13-7*q-e
    if e==4*q-1: return 15-9*q
    return 18-11*q


def b_frequency2(q,e):
    if e==1: return 19*q*q+q
    if e==2: return 17*q*q-q
    if e==3: return 17*q*q-q-2
    if e==4: return 16*q*q+10*q-22
    if e<=q+2: return 18*q*q+2*q*e-4*q-e*e+5*e-4
    if e==q+3: return 18*q*q-4*q+4
    if e<=2*q: return 16*q*q+4*q*e-24*q-2*e*e+18*e-32
    if e==2*q+1: return 16*q*q+12*q-24
    if e==2*q+2: return 16*q*q+10*q-20
    if e<=3*q: return 12*q*q+4*q*e+16*q-e*e-3*e-14
    if e==3*q+1: return 17*q*q+11*q-24
    if e<=4*q-2: return -14*q*q+16*q*e+26*q-2*e*e-6*e
    if e==4*q-1: return 18*q*q+6*q-2
    return 18*q*q+2*q-4


def verify_group_formulas(q):
    R,N,_ = forms(q)
    fr={tag:frequencies_of(members,4*q) for tag,members in R.items()}
    fa={tag:frequencies_of(members,4*q) for tag,members in N.items()}
    for e in range(1,4*q+1):
        rc,nc=group_formula_counts(q,e)
        assert rc=={tag:f[e-1] for tag,f in fr.items()},(q,e,'R',rc,{tag:f[e-1] for tag,f in fr.items()})
        assert nc=={tag:f[e-1] for tag,f in fa.items()},(q,e,'N',nc,{tag:f[e-1] for tag,f in fa.items()})
        assert sum(nc.values())-sum(rc.values())==delta_formula(q,e),(q,e,'delta')
        assert v_frequency2(q,e)+2*delta_formula(q,e)==b_frequency2(q,e),(q,e,'polynomial')
    return True


def exploratory():
    for q in (4,5,6,7,8,9,10,12,20,32,64,128):
        ds = delta_by_enumeration(q)
        vals = [(v_frequency2(q,e)+2*ds[e-1])//2 for e in range(1,4*q+1)]
        lo, hi = min(vals), max(vals)
        print(q, "min",lo,[i+1 for i,v in enumerate(vals) if v==lo],
              "max",hi,[i+1 for i,v in enumerate(vals) if v==hi],
              "weight2",2*sum(vals),flush=True)
        if q == 20:
            print("delta",list(enumerate(ds,1)),flush=True)


def solve_linear(rows, ys):
    """Exact rational Gaussian elimination; reject underdetermination."""
    a = [[Fraction(v) for v in row]+[Fraction(y)] for row,y in zip(rows,ys)]
    coln, rown = len(rows[0]), len(rows)
    pivot = 0
    for col in range(coln):
        pr = next((i for i in range(pivot,rown) if a[i][col]),None)
        if pr is None: raise ValueError("underdetermined")
        a[pivot], a[pr] = a[pr], a[pivot]
        v = a[pivot][col]
        a[pivot] = [x/v for x in a[pivot]]
        for i in range(rown):
            if i != pivot:
                v = a[i][col]
                a[i] = [x-v*y for x,y in zip(a[i],a[pivot])]
        pivot += 1
    assert not any(all(x==0 for x in row[:-1]) and row[-1] for row in a)
    return [a[i][-1] for i in range(coln)]


CELLS = [
    ("one", lambda q: (1,1)), ("two",lambda q:(2,2)),
    ("three",lambda q:(3,3)), ("four",lambda q:(4,4)),
    ("left1",lambda q:(5,q+2)), ("qplus3",lambda q:(q+3,q+3)),
    ("left2",lambda q:(q+4,2*q)), ("hplus1",lambda q:(2*q+1,2*q+1)),
    ("hplus2",lambda q:(2*q+2,2*q+2)), ("middle",lambda q:(2*q+3,3*q)),
    ("r",lambda q:(3*q+1,3*q+1)), ("right",lambda q:(3*q+2,4*q-2)),
    ("nminus1",lambda q:(4*q-1,4*q-1)), ("n",lambda q:(4*q,4*q))]


def fit_delta_cells():
    d = {q:delta_by_enumeration(q) for q in range(4,33)}
    for name, limits in CELLS:
        fixed = all(limits(q)[0]==limits(q)[1] for q in range(6,12))
        samples = [(q,e) for q in range(4,33) for e in range(limits(q)[0],limits(q)[1]+1)]
        basis = (lambda q,e:[q,1]) if fixed else (lambda q,e:[q,e,1])
        coef = solve_linear([basis(q,e) for q,e in samples],[d[q][e-1] for q,e in samples])
        print(name, list(map(str,coef)), "q,1" if fixed else "q,e,1",flush=True)


def validate_and_report():
    started=time.monotonic()
    rng=random.Random(20261024)
    closure_q=list(range(4,33))+sorted(rng.sample(range(35,73),3))
    group_q=list(range(4,65))+[97,193,257]
    payload={
        'scope':'Numerical independent validation and exact symbolic interval formulas; not a Lean proof of the frequency bridge',
        'q_domain':'all formulas intended for integers q>=4 and 1<=e<=4q',
        'finite_validation_only':True,
        'closure_q':closure_q,'group_q':group_q,
        'derivation':'B_frequency=V_frequency-removed_frequency+added_frequency; each of the 43 group counts is a finite interval count, not a fit',
        'formulas':{
            'closure_size2':'23*q*q+7*q+2',
            'minimum_frequency2':'15*q*q+7*q-14','minimum_coordinates':'{3*q}',
            'maximum_frequency2':'19*q*q+q+2','maximum_coordinates':'{q+2} for q>=5; {6,15} at q=4',
            'total_weight2':'69*q*q*q+15*q*q-18*q-34',
            'weight_delta_ordinary':'-35*q*q+35*q+26',
            'minimum_ratio_minus_15_over_23_numerator':'23*min2-15*M2=8*(7*q-44); >=0 exactly q>=7',
            'minimum_ratio_uniform_lower':'min2/M2>=127/199, equality exactly q=4',
            'minimum_ratio_lower_difference':'199*min2-127*M2=8*(q-4)*(8*q+95)',
            'maximum_vs_coordinate1':'max frequency minus frequency(1)=1',
            'all_elements_abundant':'2*min2-M2=7*q*q+7*q-30>0 for q>=4'},
        'closure_records':[],'group_records':[]}
    for q in group_q:
        verify_group_formulas(q)
        payload['group_records'].append({'q':q,'all43counts_match_at_all_coordinates':True,
            'delta_piecewise_matches_all_coordinates':True,'B_equals_V_plus_twice_delta':True})
        print('43 group formulas verified',q,flush=True)
    for q in closure_q:
        rows=explicit_B(q)
        closed=search.nf.closure(rows)
        bfs=search.closure_bfs(rows)
        assert closed==bfs,(q,'independent closure')
        old=search.nf.closure(search.variant(q))
        R,N,_=forms(q)
        removed,added=set().union(*R.values()),set().union(*N.values())
        assert old-closed==removed and closed-old==added
        actual=frequencies_of(closed,4*q)
        target=[b_frequency2(q,e) for e in range(1,4*q+1)]
        assert [2*f for f in actual]==target,(q,'actual full spectrum')
        assert 2*len(closed)==23*q*q+7*q+2
        assert 2*sum(actual)==69*q**3+15*q*q-18*q-34
        assert sum(mask.bit_count() for mask in closed)==sum(actual)
        lo,hi=min(actual),max(actual)
        arglo=[e for e in range(1,4*q+1) if actual[e-1]==lo]
        arghi=[e for e in range(1,4*q+1) if actual[e-1]==hi]
        assert 2*lo==15*q*q+7*q-14 and arglo==[3*q]
        assert 2*hi==19*q*q+q+2 and arghi==([6,15] if q==4 else [q+2])
        payload['closure_records'].append({'q':q,'closure_members':len(closed),
            'independent_BFS_matches_fold':True,'all_actual_difference_sets_match':True,
            'frequency_vector':actual,'min':lo,'argmin':arglo,'max':hi,'argmax':arghi,
            'total_weight':sum(actual),'weight_independently_equals_bit_count_sum':True,
            'closure_sha256':hashlib.sha256(json.dumps(sorted(closed)).encode()).hexdigest()})
        payload['elapsed_seconds']=round(time.monotonic()-started,3)
        (HERE/'spectrum_finite_validation.json').write_text(json.dumps(payload,indent=2),encoding='utf-8')
        print('actual closure spectrum independently verified',q,len(closed),flush=True)
    lines=['六行构造 B 的完整频数谱：符号推导与独立有限核验','',
        'q>=4，n=4q，f_B(e)表示实际非空并闭包中含坐标e的集合数。',
        '普通频数差delta=f_B-f_V，逐组计数用整数闭区间的截断长度，非数值拟合。',
        '43组具体表达式：derive_spectrum.py::group_formula_counts；可机读AST：pointwise_group_counts_ast.json。',
        '本报告中的独立有限核验不代替Lean全参数频数定理；正式桥接由团队另行证明。','',
        '闭包大小：2M=23q^2+7q+2。',
        '2f_B(e)分段：',
        'e=1: 19q^2+q',
        'e=2: 17q^2-q',
        'e=3: 17q^2-q-2',
        'e=4: 16q^2+10q-22',
        '5<=e<=q+2: 18q^2+2qe-4q-e^2+5e-4',
        'e=q+3: 18q^2-4q+4',
        'q+4<=e<=2q: 16q^2+4qe-24q-2e^2+18e-32',
        'e=2q+1: 16q^2+12q-24',
        'e=2q+2: 16q^2+10q-20',
        '2q+3<=e<=3q: 12q^2+4qe+16q-e^2-3e-14',
        'e=3q+1: 17q^2+11q-24',
        '3q+2<=e<=4q-2: -14q^2+16qe+26q-2e^2-6e',
        'e=4q-1: 18q^2+6q-2',
        'e=4q: 18q^2+2q-4','',
        '唯一最小坐标3q，2min=15q^2+7q-14。',
        'q>=5唯一最大坐标q+2；q=4最大坐标6和15并列；2max=19q^2+q+2。',
        '最大频数恰比坐标1的频数多1。',
        '总权重：2W=69q^3+15q^2-18q-34；W_B-W_V=-35q^2+35q+26。',
        '所有坐标在闭包中都超过半数；源族的各坐标频数仍为2q+1，低于(4q+3)/2。',
        'min/M>=15/23当且仅当q>=7；全q>=4的统一下界是127/199，q=4取等号。','',
        f'43组逐点核验参数：{group_q}',
        f'两独立闭包算法/全部坐标/独立总权重核验参数：{closure_q}',
        f'运行耗时：{round(time.monotonic()-started,3)}秒。',
        '未对外发布；未声称在所有合法构造中全局最优。']
    (HERE/'完整频数谱_推导与有限核验.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('report complete',round(time.monotonic()-started,3),'seconds',flush=True)


if __name__ == "__main__":
    validate_and_report()
