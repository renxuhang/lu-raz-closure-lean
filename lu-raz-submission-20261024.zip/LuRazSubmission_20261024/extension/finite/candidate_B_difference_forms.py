import search_from_variant as search

def forms(q):
    h, n, r = 2 * q, 4 * q, 3 * q + 1
    I, s = search.nf.interval, search.nf.singleton
    A, B, C = I(5, q + 2), I(r + 1, n), I(5, h + 2) | s(r)
    Ct, Cp = I(5, h + 1) | s(r), I(5, h + 1) | s(r) | s(n - 1)
    Lp = I(5, h + 1) | s(n)
    Zp = I(5, h) | I(n - 1, n)
    Ep = I(h + 3, n - 2) | s(n)
    Lnew = I(5, h + 2)
    P = list(range(4, q + 2)) + list(range(q + 3, h + 2))
    beta = lambda t: h + t if t <= q + 1 else h + t - 1
    R, N, descriptions = {}, {}, {}

    def group(dest, tag, core, values, description):
        vals = [core | v for v in values]
        assert len(vals) == len(set(vals)), (q, tag, "internal duplicate")
        assert not (set(vals) & set().union(*dest.values())), (q, tag, "cross duplicate")
        dest[tag] = set(vals)
        descriptions[tag] = {"core": core, "tail_formula": description}

    group(R, "R2", 2, [I(h + 1, n)], "[h+1,n]")
    group(R, "R3", 3, [A | I(h + 1, n)], "A union [h+1,n]")
    group(R, "R4", 4, [C, C | B], "C; C union B")
    group(R, "R5", 5, [C], "C")
    group(R, "R6C_regular", 6,
          [C | I(beta(t), n) for t in P if t <= h and t != q + 3],
          "C union [beta(t),n], t in P, t<=h, t!=q+3")
    group(R, "R6C_exception", 6, [C | I(r, n - 1)], "C union [r,n-1]")
    group(R, "R6D", 6,
          [I(5, p) | I(h + 1, n) for p in P if p <= h - 1] + [I(5, n)],
          "[5,p] union [h+1,n], p in P, p<=h-1; [5,n]")
    group(R, "R7fresh", 7, [Ep, A | Ep, I(5, n - 2) | s(n)],
          "Ep; A union Ep; [5,n-2] union {n}")
    group(R, "R7E", 7, [I(5, p) | I(h + 3, n) for p in range(4, q + 2)],
          "[5,p] union [h+3,n], 4<=p<=q+1")
    group(R, "R7D", 7, [I(5, p) | I(h + 1, n) for p in range(4, h)],
          "[5,p] union [h+1,n], 4<=p<=h-1")
    group(R, "R10", 10, [I(t, n - 1) for t in [h + 2, h + 3]],
          "[t,n-1], t in {h+2,h+3}")
    group(R, "R11J", 11, [I(a, n - 1) for a in range(5, h + 2)],
          "[a,n-1], 5<=a<=h+1")
    group(R, "R11AJ", 11, [A | I(a, n - 1) for a in range(q + 4, h + 2)],
          "A union [a,n-1], q+4<=a<=h+1")
    group(R, "R11AK", 11, [A | I(t, n - 1) for t in [h + 2, h + 3]],
          "A union [t,n-1], t in {h+2,h+3}")
    group(R, "R12", 12, [Lp, Lp | B, Lp | C, Lp | C | B],
          "Lp; Lp union B; Lp union C; Lp union C union B")
    group(R, "R13CJ", 13, [I(5, b) | s(r) for b in range(h + 2, r - 1)],
          "[5,b] union {r}, h+2<=b<=r-2")
    group(R, "R13ZJ", 13, [I(5, b) | s(n) for b in range(h + 2, n - 2)],
          "[5,b] union {n}, h+2<=b<=n-3")
    group(R, "R13CZJ", 13, [I(5, b) | s(r) | s(n) for b in range(h + 2, r - 1)],
          "[5,b] union {r,n}, h+2<=b<=r-2")
    group(R, "R13points", 13, [Lp, Lp | B, I(5, h + 1) | I(n - 1, n)],
          "Lp; Lp union B; [5,h+1] union [n-1,n]")
    group(R, "R14points", 14, [I(5, n - 2), I(5, q + 3) | I(h + 3, n - 1),
          I(5, n - 2) | s(n)],
          "[5,n-2]; [5,q+3] union [h+3,n-1]; [5,n-2] union {n}")
    group(R, "R14line", 14, [I(5, h + 1) | I(t, n) for t in range(h + 4, n)],
          "[5,h+1] union [t,n], h+4<=t<=n-1")
    group(R, "R14C", 14, [C | I(t, n) for t in range(h + 4, n) if t != r + 1],
          "C union [t,n], h+4<=t<=n-1, t!=r+1")
    group(R, "R15points", 15, [I(5, q + 3) | I(h + 3, n - 1),
          I(5, h + 1) | I(h + 3, n - 2) | s(n)],
          "[5,q+3] union [h+3,n-1]; [5,h+1] union [h+3,n-2] union {n}")
    group(R, "R15right", 15, [I(a, n - 2) | s(n) for a in range(6, h + 3)],
          "[a,n-2] union {n}, 6<=a<=h+2")
    group(R, "R15gap", 15, [A | I(a, n - 2) | s(n) for a in range(q + 4, h + 3)],
          "A union [a,n-2] union {n}, q+4<=a<=h+2")
    group(R, "R15line", 15, [I(5, h + 1) | I(t, n) for t in range(h + 4, n)],
          "[5,h+1] union [t,n], h+4<=t<=n-1")
    group(R, "R15short", 15, [I(5, p) | I(t, n) for p in range(4, q + 2)
          for t in [h + 2, h + 3]],
          "[5,p] union [t,n], 4<=p<=q+1, t in {h+2,h+3}")

    group(N, "N4", 4, [Cp, Cp | B], "Cp; Cp union B")
    group(N, "N5", 5, [Lnew, Cp, Lnew | Cp, Lnew | Zp, Cp | Zp,
          Lnew | B, Cp | B],
          "Lnew; Cp; Lnew union Cp; Lnew union Zp; Cp union Zp; Lnew union B; Cp union B")
    group(N, "N6C_regular", 6,
          [Ct | I(beta(t), n) for t in P if t <= h and t != q + 3],
          "Ct union [beta(t),n], t in P, t<=h, t!=q+3")
    group(N, "N6C_exception", 6, [Ct | I(r, n - 1)], "Ct union [r,n-1]")
    group(N, "N6E", 6, [I(5, p) | I(h + 3, n) for p in P],
          "[5,p] union [h+3,n], p in P")
    group(N, "N7C_regular", 7,
          [Ct | I(beta(t), n) for t in P if t <= h and t != q + 3],
          "Ct union [beta(t),n], t in P, t<=h, t!=q+3")
    group(N, "N7C_exception", 7, [Ct | I(r, n - 1)], "Ct union [r,n-1]")
    group(N, "N7right", 7, [Lnew | I(t, n) for t in range(r + 1, n)] +
          [Lnew | I(r + 1, n - 1)],
          "Lnew union [t,n], r+1<=t<=n-1; Lnew union [r+1,n-1]")
    group(N, "N7point", 7, [I(5, h + 1) | I(h + 3, n)],
          "[5,h+1] union [h+3,n]")
    group(N, "N10", 10, [I(t, n - 2) | s(n) for t in [h + 1, h + 2, h + 3]],
          "[t,n-2] union {n}, t in {h+1,h+2,h+3}")
    group(N, "N11J", 11, [I(a, n - 2) | s(n) for a in range(5, h + 2)],
          "[a,n-2] union {n}, 5<=a<=h+1")
    group(N, "N11AJ", 11, [A | I(a, n - 2) | s(n) for a in range(q + 4, h + 2)],
          "A union [a,n-2] union {n}, q+4<=a<=h+1")
    group(N, "N11AK", 11, [A | I(t, n - 2) | s(n) for t in [h + 2, h + 3]],
          "A union [t,n-2] union {n}, t in {h+2,h+3}")
    group(N, "N13plain", 13, [I(5, b) for b in range(h + 2, r)],
          "[5,b], h+2<=b<=r-1")
    group(N, "N13isolated", 13, [I(5, b) | s(r) | s(n - 1) for b in range(h + 2, r - 1)],
          "[5,b] union {r,n-1}, h+2<=b<=r-2")
    group(N, "N13right", 13, [I(5, b) | s(n - 1) for b in range(r, n - 2)],
          "[5,b] union {n-1}, r<=b<=n-3")
    return R, N, descriptions
