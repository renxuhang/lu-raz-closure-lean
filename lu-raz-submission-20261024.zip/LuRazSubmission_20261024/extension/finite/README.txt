独立数值复现（仅使用Python标准库）：python finite/derive_spectrum.py
该脚本从实际源族计算fold闭包与BFS闭包，逐集合/逐坐标核对频数，
另外以集合bit_count之和独立核对总权重。它不调用Lean。
有限核验用于交叉检查；一般q>=4的数学结论由包内Lean证明给出。
normal_forms.py原样取自此前冻结包，其余三个适配器仅提取原已核验函数。
