import search_from_variant as search

def explicit_B(q):
    rows = search.nf.generators(q)
    h, n, r = 2 * q, 4 * q, 3 * q + 1
    I, s = search.nf.interval, search.nf.singleton
    rows[1] = s(2) | s(4) | I(h + 1, n - 2) | s(n)
    rows[2] = s(1) | s(3) | I(5, h) | s(n - 1) | s(n)
    rows[4] = s(2) | s(3) | I(h + 3, n)
    rows[h + 2] = s(2) | s(4) | I(h + 3, n - 2) | s(n)
    rows[n - 1] = s(1) | s(3) | I(5, h + 2)
    rows[n] = s(3) | I(5, h + 1) | s(r) | s(n - 1)
    return rows

candidate_B=explicit_B
