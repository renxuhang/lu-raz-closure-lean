from collections import deque
import normal_forms as nf

def variant(q):
    rows = nf.generators(q)
    n = 4 * q
    for i, remove, add in [(2, 4, n - 1), (4, n - 1, 2), (n - 1, 2, 4)]:
        assert rows[i] >> (remove - 1) & 1
        assert not (rows[i] >> (add - 1) & 1)
        rows[i] ^= (1 << (remove - 1)) | (1 << (add - 1))
    return rows

def closure_bfs(rows):
    """Union Cayley graph traversal, independent of nf's row-by-row fold."""
    reached = set(rows)
    queue = deque(rows)
    while queue:
        a = queue.popleft()
        for b in rows:
            c = a | b
            if c not in reached:
                reached.add(c)
                queue.append(c)
    return reached
