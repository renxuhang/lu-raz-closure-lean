# Lu--Raz technical review package

The primary/ folder retains the unchanged original public count proof.
The extension/ folder contains the separate three-row/six-row results.
Read primary/PROOF.txt and primary/SOURCE_PROGRAM_EVIDENCE.txt first,
then extension/PROOF_EXTENSION.txt and its statement correspondence.

From this top-level folder, using an already installed Lean 4.35.0:

```
python -X utf8 primary/reproduce.py --toolchain leanprover/lean4:v4.35.0
python -X utf8 extension/reproduce_extension.py --toolchain leanprover/lean4:v4.35.0
```

The two scripts resolve their own source directories. No package download.
For the independent numerical cross-check, run
`python -X utf8 extension/finite/derive_spectrum.py`.
The extension fresh build/audit/replay report is extension/extension-reproduction.json.
Problem acceptance, eligibility, priority and reward remain pending official review.
